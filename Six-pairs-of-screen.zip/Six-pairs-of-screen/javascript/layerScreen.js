function check1() {
  layer.open({
    type: 2,
    title: false,
    shadeClose: true, //点击遮罩关闭层
    area: ["53.3vw", "95%"],
    offset: "4.63vh",
    content: "layerHtml/check1.html"
  });
}

function tilteH() {
  layer.open({
    type: 2,
    title: false,
    shadeClose: true, //点击遮罩关闭层
    area: ["99%", "95%"],
    offset: "4.63vh",
    content: "layerHtml/tilteH.html"
  });
}


function qx() {
  layer.open({
    type: 2,
    title: false,
    shadeClose: true, //点击遮罩关闭层
    area: ["53.3vw", "95%"],
    offset: "4.63vh",
    content: "layerHtml/qx.html"
  });
}

function listA() {
  layer.open({
    type: 2,
    title: false,
    shadeClose: true, //点击遮罩关闭层
    area: ["53.3vw", "95%"],
    offset: "4.63vh",
    content: "layerHtml/check1.html"
  });
}

function check2() {
  layer.open({
    type: 2,
    title: false,
    shadeClose: true, //点击遮罩关闭层
    area: ["53.3vw", "95%"],
    offset: "4.63vh",
    content: "layerHtml/check2.html"
  });
}

function check2Month(num) {
  layer.open({
    type: 2,
    title: false,
    shadeClose: true, //点击遮罩关闭层
    area: ["53.3vw", "95%"],
    offset: "4.63vh",
    content: "layerHtml/check2Month.html?num=" + num
  });
}

function check3() {
  layer.open({
    type: 2,
    title: false,
    shadeClose: true, //点击遮罩关闭层
    area: ["53.3vw", "95%"],
    offset: "4.63vh",
    content: "layerHtml/check3.html"
  });
}

function check5() {
  layer.open({
    type: 2,
    title: false,
    shadeClose: true, //点击遮罩关闭层
    area: ["53.3vw", "95%"],
    offset: "4.63vh",
    content: "layerHtml/check5.html"
  });
}

function check5Month(num) {
  layer.open({
    type: 2,
    title: false,
    shadeClose: true, //点击遮罩关闭层
    area: ["53.3vw", "95%"],
    offset: "4.63vh",
    content: "layerHtml/check5Month.html?num=" + num
  });
}

function check6() {
  layer.open({
    type: 2,
    title: false,
    shadeClose: true, //点击遮罩关闭层
    area: ["53.3vw", "95%"],
    offset: "4.63vh",
    content: "layerHtml/check6.html"
  });
}

function fx() {
  layer.open({
    type: 2,
    title: false,
    shadeClose: true, //点击遮罩关闭层
    skin: "layer-ext-myskin3",
    area: ["99%", "95%"],
    offset: "4.63vh",
    content: "layerHtml/fx.html"
  });
}
function gyfx() {
  layer.open({
    type: 2,
    title: false,
    shadeClose: true, //点击遮罩关闭层
    skin: "layer-ext-myskin3",
    area: ["99%", "95%"],
    offset: "4.63vh",
    content: "layerHtml/gyfx.html"
  });
}
function dtfx() {
  layer.open({
    type: 2,
    title: false,
    shadeClose: true, //点击遮罩关闭层
    skin: "layer-ext-myskin3",
    area: ["99%", "95%"],
    offset: "4.63vh",
    content: "layerHtml/dtfx.html"
  });
}
function zygk() {
  layer.open({
    type: 2,
    title: false,
    shadeClose: true, //点击遮罩关闭层
    skin: "layer-ext-myskin3",
    area: ["99%", "95%"],
    offset: "4.63vh",
    content: "layerHtml/zygk.html"
  });
}
function xqa() {
  layer.open({
    type: 2,
    title: false,
    shadeClose: true, //点击遮罩关闭层
    skin: false,
    area: ["53.3vw", "94.8vh"],
    offset: "4.63vh",
    content: "layerHtml/xqa.html"
  });
}

function xqa2() {
  layer.open({
    type: 2,
    title: false,
    shadeClose: true, //点击遮罩关闭层
    skin: "layer-ext-myskin3",
    area: ["53.3vw", "95%"],
    offset: "4.63vh",
    content: "layerHtml/xqa2.html"
  });
}

function xqa3() {
  layer.open({
    type: 2,
    title: false,
    shadeClose: true, //点击遮罩关闭层
    skin: "layer-ext-myskin3",
    area: ["53.3vw", "95%"],
    offset: "4.63vh",
    content: "layerHtml/xqa3.html"
  });
}

function xqa4() {
  layer.open({
    type: 2,
    title: false,
    shadeClose: true, //点击遮罩关闭层
    skin: "layer-ext-myskin3",
    area: ["53.3vw", "95%"],
    offset: "4.63vh",
    content: "layerHtml/xqa4.html"
  });
}

function xqa5() {
  layer.open({
    type: 2,
    title: false,
    shadeClose: true, //点击遮罩关闭层
    skin: "layer-ext-myskin3",
    area: ["53.3vw", "95%"],
    offset: "4.63vh",
    content: "layerHtml/xqa5.html"
  });
}

function xqa6() {
  layer.open({
    type: 2,
    title: false,
    shadeClose: true, //点击遮罩关闭层
    skin: "layer-ext-myskin3",
    area: ["53.3vw", "95%"],
    offset: "4.63vh",
    content: "layerHtml/xqa6.html"
  });
}

function fxWorkFlow() {
  layer.open({
    type: 2,
    title: false,
    shadeClose: true, //点击遮罩关闭层
    area: ["73.3vw", "95%"],
    offset: "4.63vh",
    content: "layerHtml/fxWorkFlow.html"
  });
}

function xyjg() {
  layer.open({
    type: 2,
    title: false,
    shadeClose: true, //点击遮罩关闭层
    area: ["99%", "95%"],
    offset: "4.63vh",
    content: "layerHtml/creditEvaluation.html"
  });
}

function gx() {
  layer.open({
    type: 2,
    title: false,
    shadeClose: true, //点击遮罩关闭层
    area: ["53.3vw", "95%"],
    offset: "4.63vh",
    content: "layerHtml/i.html"
  });
}

function credit1() {
  layer.open({
    type: 2,
    title: false,
    shadeClose: true, //点击遮罩关闭层
    area: ["53.3vw", "95%"],
    offset: "4.63vh",
    content: "layerHtml/credit1.html"
  });
}

function credit2() {
  layer.open({
    type: 2,
    title: false,
    shadeClose: true, //点击遮罩关闭层
    area: ["53.3vw", "95%"],
    offset: "4.63vh",
    content: "layerHtml/credit2.html"
  });
}

function credit3() {
  layer.open({
    type: 2,
    title: false,
    shadeClose: true, //点击遮罩关闭层
    area: ["53.3vw", "95%"],
    offset: "4.63vh",
    content: "layerHtml/credit3.html"
  });
}

function credit4() {
  layer.open({
    type: 2,
    title: false,
    shadeClose: true, //点击遮罩关闭层
    area: ["53.3vw", "95%"],
    offset: "4.63vh",
    content: "layerHtml/credit4.html"
  });
}

function px() {
  layer.open({
    type: 2,
    title: false,
    shadeClose: true, //点击遮罩关闭层
    area: ["53.3vw", "95%"],
    offset: "4.63vh",
    content: "layerHtml/k.html"
  });
}

function credit5Month(num) {
  layer.open({
    type: 2,
    title: false,
    shadeClose: true, //点击遮罩关闭层
    area: ["53.3vw", "95%"],
    offset: "4.63vh",
    content: "layerHtml/credit5Month.html?num=" + num
  });
}

function credit6() {
  layer.open({
    type: 2,
    title: false,
    shadeClose: true, //点击遮罩关闭层
    area: ["53.3vw", "95%"],
    offset: "4.63vh",
    content: "layerHtml/credit6.html"
  });
}

function credit7() {
  layer.open({
    type: 2,
    title: false,
    shadeClose: true, //点击遮罩关闭层
    area: ["53.3vw", "95%"],
    offset: "4.63vh",
    content: "layerHtml/credit7.html"
  });
}

function credit8() {
  layer.open({
    type: 2,
    title: false,
    shadeClose: true, //点击遮罩关闭层
    area: ["53.3vw", "95%"],
    offset: "4.63vh",
    content: "layerHtml/credit8.html"
  });
}

function credit9() {
  layer.open({
    type: 2,
    title: false,
    shadeClose: true, //点击遮罩关闭层
    area: ["53.3vw", "95%"],
    offset: "4.63vh",
    content: "layerHtml/credit9.html"
  });
}

function risk1() {
  layer.open({
    type: 2,
    title: false,
    shadeClose: true, //点击遮罩关闭层
    area: ["53.3vw", "95%"],
    offset: "4.63vh",
    content: "layerHtml/risk1.html"
  });
}


function sx() {
  layer.open({
    type: 2,
    title: false,
    shadeClose: true, //点击遮罩关闭层
    area: ["53.3vw", "95%"],
    offset: "4.63vh",
    content: "layerHtml/m.html"
  });
}

function risk21() {
  layer.open({
    type: 2,
    title: false,
    shadeClose: true, //点击遮罩关闭层
    area: ["53.3vw", "95%"],
    offset: "4.63vh",
    content: "layerHtml/risk21.html"
  });
}

function risk22() {
  layer.open({
    type: 2,
    title: false,
    shadeClose: true, //点击遮罩关闭层
    area: ["53.3vw", "95%"],
    offset: "4.63vh",
    content: "layerHtml/risk22.html"
  });
}

function risk23() {
  layer.open({
    type: 2,
    title: false,
    shadeClose: true, //点击遮罩关闭层
    area: ["53.3vw", "95%"],
    offset: "4.63vh",
    content: "layerHtml/risk23.html"
  });
}

function risk3() {
  layer.open({
    type: 2,
    title: false,
    shadeClose: true, //点击遮罩关闭层
    area: ["53.3vw", "95%"],
    offset: "4.63vh",
    content: "layerHtml/risk3.html"
  });
}

function risk4() {
  layer.open({
    type: 2,
    title: false,

    shadeClose: true, //点击遮罩关闭层
    area: ["53.3vw", "95%"],
    offset: "4.63vh",
    content: "layerHtml/risk4.html"
  });
}
function ssj() {
  layer.open({
    type: 2,
    title: false,
    skin: false,
    shadeClose: true, //点击遮罩关闭层
    area: ["53.3vw", "95%"],
    offset: "4.63vh",
    content: "layerHtml/ssj.html"
  });
}
function sense4() {
  layer.open({
    type: 2,
    title: false,
    shadeClose: true, //点击遮罩关闭层
    area: ["53.3vw", "95%"],
    offset: "4.63vh",
    content: "layerHtml/sense4.html"
  });
}



function ts() {
  layer.open({
    type: 2,
    title: false,
    shadeClose: true, //点击遮罩关闭层
    area: ["53.3vw", "95%"],
    offset: "4.63vh",
    content: "layerHtml/o.html"
  });
}

function kps() {
  layer.open({
    type: 2,
    title: false,
    shadeClose: true, //点击遮罩关闭层
    area: ["24.3vw", "24%"],
    offset: "4.63vh",
    top: "4.63vh",
    content: "layerHtml/kps.html"
  });
}

function temperature() {
  layer.open({
    type: 2,
    title: false,
    shadeClose: true, //点击遮罩关闭层
    area: ["53.3vw", "95%"],
    offset: "4.63vh",
    top: "4.63vh",
    content: "layerHtml/temperature.html"
  });
}

function Storage() {
  layer.open({
    type: 2,
    title: false,
    shadeClose: true, //点击遮罩关闭层
    area: ["53.3vw", "95%"],
    offset: "4.63vh",
    top: "4.63vh",
    content: "layerHtml/Storage.html"
  });
}

function pxde() {
  layer.open({
    type: 2,
    title: false,
    shadeClose: true, //点击遮罩关闭层
    area: ["53.3vw", "95%"],
    offset: "4.63vh",
    top: "4.63vh",
    content: "layerHtml/pxde.html"
  });
}

function kz() {
  layer.open({
    type: 2,
    title: false,
    shadeClose: true, //点击遮罩关闭层
    area: ["53.3vw", "95%"],
    offset: "4.63vh",
    content: "layerHtml/p.html"
  });
}

function pc() {
  layer.open({
    type: 2,
    title: false,
    shadeClose: true, //点击遮罩关闭层
    area: ["53.3vw", "95%"],
    offset: "4.63vh",
    content: "layerHtml/q.html"
  });
}

function le() {
  layer.open({
    type: 2,
    title: false,
    offset: '100px',
    skin: "layer-ext-myskin3",
    shadeClose: true, //点击遮罩关闭层
    area: ["39.4vw", "58vh"],
    content: "layerHtml/layers.html"
  });
}





function frequency2two() {
  layer.open({
    type: 2,
    title: false,
    shadeClose: true, //点击遮罩关闭层
    area: ["53.3vw", "95%"],
    offset: "4.63vh",
    content: "layerHtml/check-data22.html"
  });
}


function punish1() {
  layer.open({
    type: 2,
    title: false,
    shadeClose: true, //点击遮罩关闭层
    area: ["53.3vw", "95%"],
    offset: "4.63vh",
    content: "layerHtml/punish1.html"
  });
}

function punish3() {
  layer.open({
    type: 2,
    title: false,
    shadeClose: true, //点击遮罩关闭层
    area: ["53.3vw", "95%"],
    offset: "4.63vh",
    content: "layerHtml/punish3.html"
  });
}



function circulars() {
  layer.open({
    type: 2,
    title: false,

    shadeClose: true, //点击遮罩关闭层
    area: ["53.3vw", "95%"],
    offset: "4.63vh",
    content: "layerHtml/c.html"
  });
}

function item() {
  layer.open({
    type: 2,
    title: false,

    shadeClose: true, //点击遮罩关闭层
    area: ["53.3vw", "95%"],
    offset: "4.63vh",
    content: "layerHtml/d.html"
  });
}

function list() {
  layer.open({
    type: 2,
    title: false,

    shadeClose: true, //点击遮罩关闭层
    area: ["53.3vw", "95%"],
    offset: "4.63vh",
    content: "layerHtml/f.html"
  });
}

function licence1() {
  layer.open({
    type: 2,
    title: false,
    shadeClose: true, //点击遮罩关闭层
    area: ["53.3vw", "95%"],
    offset: "4.63vh",
    content: "layerHtml/licence1.html"
  });
}

function licence2() {
  layer.open({
    type: 2,
    title: false,
    shadeClose: true, //点击遮罩关闭层
    area: ["53.3vw", "95%"],
    offset: "4.63vh",
    content: "layerHtml/licence2.html"
  });
}

function xtjg() {
  layer.open({
    type: 2,
    title: false,
    shadeClose: true, //点击遮罩关闭层
    area: ["53.3vw", "75.2%"],
    offset: "4.63vh",
    content: "layerHtml/xtjg.html"
  });
}

function fxjg() {
  layer.open({
    type: 2,
    title: false,

    shadeClose: true, //点击遮罩关闭层
    area: ["100%", "95%"],
    offset: "4.63vh",
    content: "layerHtml/fxjg.html"
  });
}

// function xtjg() {
//   layer.open({
//     type: 2,
//     title: false,

//     shadeClose: true, //点击遮罩关闭层
//     area: ["100%", "95%"],
//     offset: "4.63vh",
//     content: "layerHtml/xtjg.html"
//   });
// }

function pic() {
  layer.open({
    type: 2,
    title: false,
    shadeClose: true, //点击遮罩关闭层
    area: ["53.3vw", "95%"],
    offset: "4.63vh",
    content: "layerHtml/g.html"
  });
}

function classification() {
  layer.open({
    type: 2,
    skin: "layer-ext-myskin2",
    title: false,
    shadeClose: true, //点击遮罩关闭层
    area: ["100%", "95%"],
    offset: "4.63vh",
    content: "layerHtml/classification.html"
  });
}

function dynamic() {
  layer.open({
    type: 2,
    skin: "layer-ext-myskin2",
    title: false,
    shadeClose: true, //点击遮罩关闭层
    area: ["100%", "95%"],
    offset: "4.63vh",
    content: "layerHtml/dynamic-supervision.html"
  });
}

function wlw() {
  layer.open({
    type: 2,
    title: false,
    shadeClose: true, //点击遮罩关闭层
    area: ["53.3vw", "95%"],
    offset: "4.63vh",
    content: "layerHtml/h.html"
  });
}


function xietong() {
  layer.open({
    type: 2,
    title: false,
    shadeClose: true, //点击遮罩关闭层
    area: ["99%", "95%"],
    offset: "4.5vh",
    content: "layerHtml/xietong.html"
  });
}

function znwl() {
  layer.open({
    type: 2,
    title: false,
    skin: 'layer-ext-myskin3',
    shadeClose: true, //点击遮罩关闭层
    area: ["99%", "95%"],
    offset: "4.63vh",
    content: "layerHtml/znwl.html"
  });
}